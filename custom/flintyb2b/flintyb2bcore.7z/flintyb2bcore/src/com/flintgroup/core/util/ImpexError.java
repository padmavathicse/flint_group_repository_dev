package com.flintgroup.core.util;

/**
 * POJO representing an Impex Error
 * 
 * @author capgemini
 */
public class ImpexError
{
	/**
	 * the msg explaining the error
	 */
	private String msg;
	/**
	 * the line in the original csv file
	 */
	private String origLine;
	/**
	 * the file name of the reject file
	 */
	private String rejectFileName;
	/**
	 * the line number in the reject file
	 */
	private int rejectLineNb;

	/**
	 * construct an Impex error with the source line
	 * 
	 * @param msg
	 *           the msg explaining the error
	 */
	public ImpexError(final String msg)
	{
		this.msg = msg;
	}

	/**
	 * construct an Impex error with the source line
	 * 
	 * @param msg
	 *           the msg explaining the error
	 * @param sourceLine
	 *           the line in the original csv file
	 */
	public ImpexError(final String msg, final String sourceLine)
	{
		this.msg = msg;
		this.origLine = sourceLine;
	}

	public final String getMsg()
	{
		return msg;
	}

	public final void setMsg(final String msg)
	{
		this.msg = msg;
	}

	public final String getOrigLine()
	{
		return origLine;
	}

	public final void setOrigLine(final String origLine)
	{
		this.origLine = origLine;
	}

	public final int getRejectLineNb()
	{
		return rejectLineNb;
	}

	public final void setRejectLineNb(final int rejectLineNb)
	{
		this.rejectLineNb = rejectLineNb;
	}

	public final String getRejectFileName()
	{
		return rejectFileName;
	}

	public final void setRejectFileName(final String rejectFileName)
	{
		this.rejectFileName = rejectFileName;
	}
}
