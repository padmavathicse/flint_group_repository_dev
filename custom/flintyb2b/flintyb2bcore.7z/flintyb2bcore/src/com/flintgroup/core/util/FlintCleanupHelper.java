package com.flintgroup.core.util;

import de.hybris.platform.acceleratorservices.dataimport.batch.BatchHeader;
import de.hybris.platform.acceleratorservices.dataimport.batch.task.CleanupHelper;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import com.flintgroup.core.util.ImpexErrorManager;
/**
 * Bean called at the end of the hot-folder process to clean source file and move it to the archive/error folder
 * This custom implementation gather source line that failed during the process using the ImpexErrorManager Singleton
 *
 * @author Capgemini
 * @see de.hybris.platform.acceleratorservices.dataimport.batch.task.CleanupHelper
 */
public class FlintCleanupHelper extends CleanupHelper
{

    /**
     * Edit the local|project.properties to change logging behavior (properties 'log4j.*').
     */
    private final Logger LOG = Logger.getLogger(this.getClass().getName());

    /**
     * rearrange the error boolean corresponding to the ImpexErrorManager.SINGLETON
     *  and get sourcelines thanks to ImpexErrorManager
     * {@inheritDoc}
     */
    @Override
    public final void cleanup(final BatchHeader header, boolean error)
    {
        error = ImpexErrorManager.SINGLETON.getErrorLines(header.getFile().getName()).size() > 0;
        final File file = header.getFile();

        if (error)
        {
            try
            {
                ImpexErrorManager.SINGLETON.resolveOrigLines(file);
            }
            catch (UnsupportedEncodingException | FileNotFoundException e)
            {
                e.printStackTrace();
            }
            LOG.info(file.getName());
        }

        super.cleanup(header, error);

        ImpexErrorManager.SINGLETON.clearErrors(header.getFile().getName());
    }

}
