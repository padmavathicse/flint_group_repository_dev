package com.flintgroup.core.util;

import de.hybris.platform.util.CSVReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Singleton class managing error files when importing a csv file in the hot folder
 *
 * @author Capgemini
 */
public enum ImpexErrorManager
{
    /**
     * singleton pattern design
     */
    SINGLETON;
    /**
     * map of file name to store theirs errors
     */
    private final Map<String, Map<Integer, ImpexError>> impexErrors;

    /**
     * encoding used to read csv files and resolve original lines
     */
    private String encoding;
    /**
     * line to skip used to read csv files and resolve original lines
     */
    private int linesToSkip;
    /**
     * field separator used to read the csv resolve original lines
     */
    private char fieldSeparator;

    /**
     * self singleton constructor
     */
    private ImpexErrorManager()
    {
        impexErrors = new ConcurrentHashMap<>();
    }

    /**
     * add an error to the file map of errors with the source line
     * @param file
     *      the file to add error
     * @param message
     *      the message to explain the error
     * @param lineNumber
     *      the line where the error is located
     * @param sourceLine
     *      the source line
     */
    public void addErrorLine(final String file, final String message, final int lineNumber, final String sourceLine)
    {
        Map<Integer, ImpexError> errorLines = getOrCreateErrorLines(file);
        errorLines.put(Integer.valueOf(lineNumber), new ImpexError(message, sourceLine));
    }

    /**
     * add an error to the file map of errors without the source line
     * @param file
     *      the file to add error
     * @param message
     *      the message to explain the error
     * @param lineNumber
     *      the line where the error is located
     */
    public void addErrorLine(final String file, final  String message, final  int lineNumber)
    {
        Map<Integer, ImpexError> errorLines = getOrCreateErrorLines(file);
        errorLines.put(Integer.valueOf(lineNumber), new ImpexError(message));
    }

    /**
     * get errors lines of the given filename
     * @param file
     *      the file to get errors
     * @return
     *      the map of error
     */
    public synchronized Map<Integer, ImpexError> getErrorLines(final String file)
    {
        if (impexErrors.containsKey(file))
        {
            return impexErrors.get(file);
        }
        else
        {
            return Collections.<Integer, ImpexError>emptyMap();
        }
    }

    /**
     * clear impexErrors of the given file
     * @param file
     *      the file to clear errors
     */
    public synchronized void clearErrors(final String file)
    {
        impexErrors.remove(file);
    }

    /**
     *  parse the source file to get original csv lines for each ImpexError.
     * @param file
     *      the file name to resolve errors
     * @throws UnsupportedEncodingException
     *      in case of a incorrect encoding option
     * @throws FileNotFoundException
     *      in case file doesn't exists
     * @see com.biomerieux.impex.logger.BmxImpexTransformerTask#createCsvReader(java.io.File)
     */
    public void resolveOrigLines(final File file)
            throws UnsupportedEncodingException, FileNotFoundException
    {
        final Map<Integer, ImpexError> errorLines = getErrorLines(file.getName());
        CSVReader csvReader = new FlintCSVReader(file, encoding, linesToSkip, fieldSeparator);

        SortedSet<Integer> keys = new TreeSet<>(errorLines.keySet());
        for (Integer lineNb : keys)
        {
            ImpexError impexError = errorLines.get(lineNb);
            while (impexError.getOrigLine() == null)
            {
                csvReader.readNextLine();
                if (lineNb.intValue() == csvReader.getCurrentLineNumber())
                {
                    impexError.setOrigLine(csvReader.getSourceLine());
                }
            }
        }
        try
        {
            csvReader.close();
        }
        catch (IOException e)
        {
            csvReader.closeQuietly();
        }
    }

    /**
     * store parse configuration to get source line with resolveOrigLines
     * @see com.biomerieux.impex.logger.BmxImpexTransformerTask#createCsvReader(java.io.File)
     * @param encode
     *      csv encoding
     * @param skippedLines
     *      csv line to skimp
     * @param fieldSep
     *      csv field separator
     */
    public void setFileParsingConfig(final String encode, final int skippedLines, final char fieldSep)
    {
        this.encoding = encode;
        this.linesToSkip = skippedLines;
        this.fieldSeparator = fieldSep;
    }

    /**
     * get or create a Map<Integer, ImpexError> of a file error in the Map<String, Map<Integer,ImpexError>> impexErrors
     * @param fileName
     *      the file name
     * @return
     *      the new or existing Map of error lines
     */
    private Map<Integer, ImpexError> getOrCreateErrorLines(final String fileName)
    {

        Map<Integer, ImpexError> errorLines = impexErrors.get(fileName);
        if (null == errorLines)
        {
            errorLines = new HashMap<>();
            impexErrors.put(fileName, errorLines);
        }
        return errorLines;
    }

}
